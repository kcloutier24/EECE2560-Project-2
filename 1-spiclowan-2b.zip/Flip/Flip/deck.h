/*
File Name: deck.h
Created by: Katherine Cloutier, Yizi Wang, & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This deck.h file was developed for part b of the Flip Cards project. This file
serves as storage for the cards in a deck. Each deck of cards is implemented
using a linked list of nodes, each containing a single Card object. A private
pointer *front is used to point to the first card in the deck, and a private
integer was used to store the size of the deck.

This class contains:
- A constructor to instantiate the deck with cards in a specifc order
- A destructor to deallocate the list of cards
- A Deal() function to return the card on the top of the deck while removing it
from the deck
- A Replace() function to insert a card to the bottom of the deck
- A getCardNode() function to return the card in a specific position in the 
deck
- An overloaded << operator to print the deck
- A Shuffle() function that shuffles the cards
*/

// Definition for header file
#ifndef DECK_CLASS
#define DECK_CLASS

// Include statements
#include <iostream>
#include <strstream>
#include <string>
#include <stdlib.h>
#include <iomanip>
#include <vector>
#include <ctime>

#include "d_node.h"
#include "card.h"

using namespace std;



class Deck
{
    // Public members of Deck Class
    public:
        // Default Constructor
        Deck(bool isEmpty);

        // Default Destructor
        ~Deck();

        // Returns the top card node in the deck while removing it from the 
        // deck
        node<Card>* Deal();

        // Places a card node on the bottom of the deck
        void Replace(node<Card>* pCard);

        // Shuffles the deck for the cards to be in a pseudo-random order
        void Shuffle();

        // Return Card object in specific position posCard
        Card getCardNode(int posCard);

        // << operator overloading for a Deck object to print all cards in the
        // deck from top to bottom
        friend ostream& operator<< (ostream& ostr, const Deck& fullDeck);

    // Private members of Deck Class
    private:
        node<Card>* front = NULL;    // Pointer pointing to front of the deck
        int linkedListSize = 0;        // Size of deck originally set to 0
};


Deck::Deck(bool isEmpty)
// Deck constructor that builds the deck. Deck is built by having all clubs on
// the top, followed by diamonds, hearts, then spades on the bottom. In each
// suit group, the values of the cards start at Ace (1) and end at King (13)
{
    if (!isEmpty)
    // if isEmpty is passed false, then deck object will initialize with 52
    // cards
    {
        // Definition of each of the suits
        vector<string> cardSuits = { "Clubs", "Diamonds", "Hearts", "Spades" };

        for (int suitVal = 3; suitVal >= 0; suitVal--)
        // For loop for card suits
        {
            for (int cardVal = 13; cardVal > 0; cardVal--)
            // For loop for card values
            {
                // Instantiates a new Card object
                Card newCard(cardVal, cardSuits[suitVal]);

                // Inserts a new card at the front of the linked list
                // (top of deck)
                node<Card>* newNode = new node<Card>(newCard, front);

                // New card inserted is the front of the linked list
                // (top of deck)
                front = newNode;

                // Increases size of deck by 1
                linkedListSize++;

            }// End card value for loop
        }// End card suit for loop
    }// End if
}// End Deck constructor


Deck::~Deck()
// Deck destructor that deallocates the list of cards
// The linked list is deleted from front.
{
    // Initiates a Card node to temporarily hold the value of front
    node<Card>* p;

    while (front != NULL)
    // While loop that goes through the entire linked list
    // Deletes one node at a time
    // Checks if the deck is empty
    {
        // p is used to store the value of the card at the top of the deck
        p = front;

        // front is moved to the next node in the linked list until it reaches
        // the end
        front = front->next;

        // the original front node is deleted in each run of the while loop
        delete p;
    }// End while
}// End Deck Destructor


node<Card>* Deck::Deal()
// Returns the top card node in the deck while removing it from the deck
{
    // Initiates a Card node to temporarily hold the value of front
    node<Card>* f = front;

    // front is moved to the next node in the linked list
    // Removes the top card node from the deck
    front = front->next;

    // The next of f node is set to NULL so that the node does not link to the 
    // other Cards
    f->next = NULL;

    // Returns the top card node
    return f;
}// End Deal() function


void Deck::Replace(node<Card>* pCard)
// Places a card node on the bottom of the deck
{
    // Initiates a Card node to temporarily hold the value of front
    node<Card>* curr;
    curr = front;

    if (front == NULL)
    // if loop to check if the deck is empty
    {
        // Places the passed in Card node to the empty deck
        front = pCard;
        // The deck only has 1 Card node at this time
    }
    else
    // If the deck is not empty
    {
        while (curr->next != NULL)
        // while loop to locate the bottom card of the deck
        {
            // If the next node is not NULL
            // The current node moves to the next Card node in the deck
            curr = curr->next;
        }// End while

        // Places the passed in Card node to the bottom of the deck
        curr->next = pCard;
    }// End if
}// End Replace() function


void Deck::Shuffle()
// This shuffes the deck of cards for a given Deck object. To shuffle the deck,
// a random number is generated to locate a specific card in the linked list.
// Then, the card is deleted from the linked list and re-inserted at the top
// (front) of the linked list
{
    // Ensures pseudo-randomness
    srand(time(0));

    // Count for the number of shuffles completed
    int shuffleCount = 0;

    // Pointer to point to previous card behind randomly selected card
    node<Card>* prevCard = NULL;

    while (shuffleCount != 10000)
    // While loop to shuffle 1 card at random 10000 times in the deck
    {
        // Pointer to point to randomly selected card to be moved
        node<Card>* card1 = front;

        // Generates random number between 0 and 51 to select card to be moved
        int cardPos = rand() % linkedListSize;

        while (cardPos > 0)
        // Advances card1 pointer to point to desired card to be moved
        {
            if (cardPos == 1)
            // Checks if cardPos equals 1; if so, the prevCard pointer must
            // point to the present card1 value
            {
                prevCard = card1;
            }// End if

            // Advance card1 to point to the next card and decrease cardPos by
            // 1
            card1 = card1->next;
            cardPos--;

        }// End while

        if (card1 != front)
        // Checks if the randomly selected card is the top of the deck. If this
        // is the case, then there is no need to move the card, as it is in the
        // correct spot. As a result, the if statement would be ignored
        {
            // Remove card that was randomly selected to be moved
            prevCard->next = card1->next;

            // Set the front of the linked list to the newly shuffled card
            card1->next = front;
            front = card1;

        }// End if

        // Add 1 to the shuffle counter
        shuffleCount++;
    }// End while for shuffling

}// End Shuffle() function


Card Deck::getCardNode(int posCard)
// Takes one input (posCard) which is used to advance a pointer to posCard
// position in the linked list. Returns the Card object contained within
// specific node
{
    // New temporary pointer for getting Card data contained within specific
    // node
    node<Card>* desiredCard = front;

    while (posCard > 1)
    // While loop to advance the desiredCard pointer to specific index in the
    // linked list
    {

        desiredCard = desiredCard->next;

        posCard--;

    }// End while

    // Return Card object contained within specific node index
    return desiredCard->nodeValue;

}// End getCardNode() function


ostream& operator<< (ostream& ostr, const Deck& fullDeck)
// Overload stream operator << with lhs input (ostr) and rhs input
// (fullDeck), which is a Deck object. The output prints all the cards in
// order from top to bottom in the deck (52 total)
{
    // Ostr functionalities to be able to print strings to the console
    ios_base::fmtflags currentFlags = ostr.flags();
    char currentFill = ostr.fill();

    // Set fill char to ' ' and enable right justification
    ostr.fill(' ');
    ostr.setf(ios::right, ios::adjustfield);

    // New pointer to iterate through linked list
    node<Card>* currentCard = fullDeck.front;

    while (currentCard != NULL)
    // Loops through each node in the linked list to print the card information
    {
        // Prints card information
        cout << currentCard->nodeValue;

        // Advance pointer to next node
        currentCard = currentCard->next;

    }// End while

    // Restore the fill char and the format flags
    ostr.fill(currentFill);
    ostr.setf(currentFlags);

    // Return the output
    return ostr;
}// End << operator overloading

#endif

// End deck.h