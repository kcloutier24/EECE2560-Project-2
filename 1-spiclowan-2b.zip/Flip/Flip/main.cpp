/*
File Name: main.cpp
Created by: Katherine Cloutier, Yizi Wang, & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This main.cpp file was developed for part b of the flip card project. The main
objective of this file is to call the playFlip global function, which goes
through and plays the Flip Card game based on the rules outlined in the handout
for the project.

Note: The bonus for the playFlip function has been implemented, where cards
that have already been selected by the user once cannot be selected again.
*/



// Include statements
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <string>

#include "deck.h"

using namespace std;



// Constant integers for the operation of the game; defined in the handout for
// the project
const int NUMBER_SHUFFLES = 3;
const int CARDS_TO_DRAW = 24;



void playFlip()
// playFlip function to play the Flip Card game as defined in the handout for
// the project
{
	// BONUS: Vector to track cards selected by the user; used for checking if
	// user attempts to draw card again.
	vector<int> selectedCards;

	// Tracks the total game points
	int gamePoints = 0;

	cout << "Welcome to the Flip Card Game!\n\n";

	// Call constructor to create deck with 52 Cards. Boolean inside
	// declaration states deck is not empty initially.
	Deck originalDeck(false);

	// Print deck in new deck order
	cout << "Deck Before Shuffling: \n";
	cout << originalDeck;

	// For loop to shuffle the deck a set number of times; defined with
	// NUMBER_SHUFFLES constant
	for (int a = 0; a < NUMBER_SHUFFLES; a++)
	{
		originalDeck.Shuffle();
	}// End for

	// Print shuffled deck
	cout << "\nDeck After Shuffling " << NUMBER_SHUFFLES << " times: \n";
	cout << originalDeck;

	// Call Deck constructor to create empty deck. Boolean inside declaration
	// states deck is empty initially
	Deck currentDeck(true);

	for (int b = 0; b < CARDS_TO_DRAW; b++)
	// Loops through the CARDS_TO_DRAW constant variable to pull specific
	// number of cards to a new deck. Pulls top card from original deck and
	// places card at the bottom of new deck
	{
		// Returns top card of original deck
		node<Card> *topCard = originalDeck.Deal();

		// Places this top card at the bottom of the new deck
		currentDeck.Replace(topCard);
	}

	// Prints cards in the new deck
	cout << "\nDeck that User Can Draw Cards From For the Game: \n";
	cout << currentDeck;

	// Prints cards in the original deck
	cout << "\nOriginal deck with " << CARDS_TO_DRAW << " less cards: \n";
	cout << originalDeck;

	// Tracks card position user would like to flip over in game
	int cardPosToDraw;

	// Starts playing the game
	cout << "\n\nThe game will now start. \n";

	int continueGame = 1;

	while (continueGame == 1 && selectedCards.size() != CARDS_TO_DRAW)
	// While loop to verify if either the user still wants to play or not all
	// the cards have been flipped over
	{
		// User prompted to enter a card position between 1 and CARDS_TO_DRAW
		cout << "\nPlease enter a number between 1 and " << CARDS_TO_DRAW 
			 << ": ";

		cin >> cardPosToDraw;

		// BONUS: variable to track if card has been selected by user
		int cardAlreadySelected = 1;

		while (cardAlreadySelected != 0)
		// BONUS: While loop to track if card has been already selected; checks
		// if card has not been selected --> 'cardAlreadySelected' = 0
		{
			// At the start of each loop, assume card is unique 
			// (cardAlreadySelected = 0)
			cardAlreadySelected = 0;

			while (cardPosToDraw < 1 || cardPosToDraw > CARDS_TO_DRAW)
			// Determine if entry is between 1 and CARDS_TO_DRAW. If not, force
			// user to enter values until entry is valid.
			{
				cout << "The number entered is not valid. Please enter a "
					<< "number between 1 and " << CARDS_TO_DRAW << ": ";

				cin >> cardPosToDraw;

			}// End while

			for (int c = 0; c < selectedCards.size(); c++)
			// BONUS: Loops through the selectedCards vector to determine if
			// card position selected by user has already been selected. If it 
			// has been selected, cardAlreadySelected integer increases by 1
			{
				if (selectedCards[c] == cardPosToDraw)
				// Checks if card is in vector
				{
					// Increase cardAlreadySelected by 1
					cardAlreadySelected++;
					break;
				}// End if
			}// End for

			if (cardAlreadySelected != 0)
			// BONUS: Checks if card has already been selected by user. If so,
			// user is prompted to select new value. All selected card 
			// positions are also printed to the console
			{
				cout << "\nYou have already selected this card. The cards you "
					 << "have selected are as follows:\n";

				for (int d = 0; d < selectedCards.size(); d++)
				// Prints all elements of the vector containing card positions
				// already selected by user
				{
					cout << selectedCards[d] << "  ";
				}

				// Prompts user to enter new card position
				cout << "\n\nPlease enter a number between 1 and " 
					 << CARDS_TO_DRAW << " that is not one of the numbers "
					 << "listed above: ";

				cin >> cardPosToDraw;
			}
			else
			// BONUS: else, card is unique and can proceed with game; card
			// position value added to vector storing used positions
			{
				// NOTE: At this point, cardAlreadySelected = 0, which means
				// while loop will be exited
				selectedCards.push_back(cardPosToDraw);

			}// End if

		}// End BONUS while

		// new Card object selectedCard to store value and suit of card 
		// selected by user
		Card selectedCard = currentDeck.getCardNode(cardPosToDraw);

		// Print selected card to user
		cout << "\nThe Selected Card was: " << selectedCard;

		switch (selectedCard.getValue())
		// Case structore for determing points scored for selected card. These
		// were defined in the project handout
		{
			case 1:
			// Ace card selected --> 10 Points
				gamePoints += 10;
				break;
			case 11: case 12: case 13:
			// Jack, Queen, or King card selected --> 5 Points
				gamePoints += 5;
				break;
			case 8: case 9: case 10:
			// 8-10 card selected --> No Points
				gamePoints += 0;
				break;
			case 7:
			// 7 card selected --> Cut Points in half
				// Rounds up if gamePoints is odd --> 7 Points / 2 = 4 Points
				gamePoints = round(float(gamePoints) / 2);
				break;
			default:
			// Default means 2-6 card selected --> total points equals 0
				gamePoints = 0;
				break;
		}// End case

		if (selectedCard.getSuit() == "Hearts")
		// Add 1 point if suit of card is Hearts
		{
			gamePoints += 1;
		}// End if

		// Print current total points to console; asks user if they would like
		// to continue playing
		cout << "\nYour current points in the game is " << gamePoints
			 << " point(s). Would you like to continue? Type '0' for NO or"
			 << " '1' for YES: ";

		cin >> continueGame;

		while (continueGame != 0 && continueGame != 1)
		// Checks if user entry is valid for continuing game; if not, user is
		// prompted to continue entering until the input is valid
		{
			cout << "The entry was not valid. Please type '0' for NO or '1'"
				 << " for YES: ";

			cin >> continueGame;
		}// End while

	}// End while for playing game

	if (continueGame == 1 && selectedCards.size() == CARDS_TO_DRAW)
	// BONUS: Printing message if all cards have been selected by user in the 
	// game; no more cards to print and games end
	{
		cout << "\n\nYou have selected all possible cards. Game is ending.";
	}// End if

	// Ending printing statements to console
	cout << "\n\nYou ended the game with " << gamePoints << " point(s). ";
	cout << "Thank you for playing! The Game is now Quitting.\n\n";

}// End playFlip function



int main()
// Main function to meet the requirements of the Flip Card Game - Part B
{
	// Calls the playFlip function
	playFlip();

	return 0;
}

// End main.cpp