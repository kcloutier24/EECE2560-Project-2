/*
File Name: card.h
Created by: Katherine Cloutier, Yizi Wang, & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This card.h file was developed for part a of the flip card project. This file
serves as a class that stores a single card. This includes suits (clubs, 
diamonds, hearts, spades) and values (Ace through King).

This class consists of:
- A constructor
- A setValue() function to set the value of the card
- A setSuit() function to set the suit of the card
- A getValue() function to get the value of the card
- A getSuit() function to get the suit of the card
- An overloaded << operator to print the value and suit of a card object
*/



// Definition for header file
#ifndef CARD_CLASS
#define CARD_CLASS

// Include statements
#include <iostream>
#include <strstream>
#include <string>
#include <stdlib.h>
#include <iomanip>
#include <vector>
#include <ctime>

using namespace std;



class Card
{
	// Public members of Card Class
	public:
		// Default Constructor
		Card(int value, string suit);

		// Sets card value
		void setValue(int cardValue);

		// Sets card suit
		void setSuit(string suitValue);

		// Returns card value
		int getValue() const;

		// Returns card suit
		string getSuit() const;

		// << operator overloading for Card class to print card suit and value
		friend ostream& operator<< (ostream& ostr, const Card& currentCard);

	// Private members of Card Class
	private:
		int value;		// A value Ace(1) - King (13) of the card
		string suit;	// Suit of the card (C, D, H, S)
};


Card::Card(int cardValue, string cardSuit)
// Constructor to initialize value and suit
{
	value = cardValue;
	suit = cardSuit;
}


void Card::setValue(int cardValue)
// Sets the private member for the card value to the provided input of the
// function (cardValue)
{
	value = cardValue;
}


void Card::setSuit(string suitValue)
// Sets the private member for the card suit to the provided input of the
// function (suitValue)
{
	suit = suitValue;
}


int Card::getValue() const
// Returns the private member for the card value (value)
{
	return value;
}


string Card::getSuit() const
// Returns the private member for the card suit (suit)
{
	return suit;
}


ostream& operator<< (ostream& ostr, const Card& currentCard)
// Overload stream operator << with lhs input (ostr) and rhs input 
// (currentCard), which is a Card object. The output first prints the card
// value (value), then the card suit (suit)
{
	// Ostr functionalities to be able to print strings to the console
	ios_base::fmtflags currentFlags = ostr.flags();
	char currentFill = ostr.fill();

	// Set fill char to ' ' and enable right justification
	ostr.fill(' ');
	ostr.setf(ios::right, ios::adjustfield);

	switch (currentCard.getValue())
	// Using a case statement to determine the face cards and output the name
	{
		case 1:
			cout << "Ace";
			break;
		case 11:
			cout << "Jack";
			break;
		case 12:
			cout << "Queen";
			break;
		case 13:
			cout << "King";
			break;
		default:
			cout << currentCard.getValue();
			break;
	}
	
	cout << " of " << currentCard.getSuit() << endl;

	// Restore the fill char and the format flags
	ostr.fill(currentFill);
	ostr.setf(currentFlags);

	// Return the output
	return ostr;
}

#endif

// End card.h