/*
File Name: main.cpp
Created by: Katherine Cloutier, Yizi Wang, & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This main.cpp file was developed for part a of the flip card project. The main
objective of this file is to initialize a deck and to print all the cards in 
the deck, once before the shuffle and an additional time after the shuffle. 
This main function includes the deck.h file.
*/



// Include statements
#include <iostream>
#include <stdlib.h>

#include "deck.h"

using namespace std;



int main()
// Main function to meet the requirements of the Flip Card Game - Part A
{
	// New Deck object deckForGame
	Deck deckForGame;

	// Prints deck before shuffling (new deck order)
	cout << "Deck Before Shuffling: \n";
	cout << deckForGame;

	// Call the Shuffle() function to shuffle deck
	deckForGame.Shuffle();

	// Prints the deck after shuffling
	cout << "\nDeck After Shuffling Once: \n";
	cout << deckForGame;

	return 0;
}

// End main.cpp